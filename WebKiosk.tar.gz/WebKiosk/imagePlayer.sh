#!/bin/sh

feh -Y -x -q -D $1 -B black -F -Z -r $2
